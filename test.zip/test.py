var pg_port=1212;
var pg_host="gitguardians.com:9082/BLUDB";
var pg_user="root";
var pg_pass="sup3rstr0ngpass1ForGG22";

var mongo_uri = "mongodb+srv://testuser22:hub24aoeu@gg-is-awesome-gg27322.mongodb.net/test?retryWrites=true&w=majority";
